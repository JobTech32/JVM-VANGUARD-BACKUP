PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS household_members;
DROP TABLE IF EXISTS income_records;
DROP TABLE IF EXISTS applicants;

CREATE TABLE applicants (
    applicant_id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    date_of_birth TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT NOT NULL,
    address_line1 TEXT NOT NULL,
    city TEXT NOT NULL,
    state TEXT NOT NULL DEFAULT 'MO' CHECK (length(state) = 2),
    zip_code TEXT NOT NULL CHECK (length(zip_code) IN (5, 10)),
    application_status TEXT NOT NULL DEFAULT 'Received'
        CHECK (application_status IN ('Draft', 'Received', 'Under Review', 'Verified', 'Needs Correction')),
    submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE income_records (
    income_id INTEGER PRIMARY KEY AUTOINCREMENT,
    applicant_id INTEGER NOT NULL,
    employer_name TEXT NOT NULL,
    job_title TEXT,
    hours_per_week REAL NOT NULL CHECK (hours_per_week >= 0 AND hours_per_week <= 168),
    gross_monthly_income REAL NOT NULL CHECK (gross_monthly_income >= 0),
    FOREIGN KEY (applicant_id) REFERENCES applicants(applicant_id) ON DELETE CASCADE
);

CREATE TABLE household_members (
    household_member_id INTEGER PRIMARY KEY AUTOINCREMENT,
    applicant_id INTEGER NOT NULL,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    relationship_to_applicant TEXT NOT NULL,
    date_of_birth TEXT NOT NULL,
    gross_monthly_income REAL NOT NULL DEFAULT 0 CHECK (gross_monthly_income >= 0),
    FOREIGN KEY (applicant_id) REFERENCES applicants(applicant_id) ON DELETE CASCADE
);

CREATE TABLE employees (
    employee_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL  -- iterations:salt:hash (PBKDF2), never the plain password
);

CREATE INDEX idx_income_applicant_id ON income_records(applicant_id);
CREATE INDEX idx_household_applicant_id ON household_members(applicant_id);

INSERT INTO applicants
    (first_name, last_name, date_of_birth, email, phone, address_line1, city, state, zip_code)
VALUES
    ('Jordan', 'Reed', '1991-04-18', 'jordan.reed@example.com', '314-555-0131', '1450 Pine Street', 'St. Louis', 'MO', '63103'),
    ('Maria', 'Lopez', '1986-11-02', 'maria.lopez@example.com', '816-555-0174', '902 Oak Avenue', 'Kansas City', 'MO', '64106'),
    ('Caleb', 'Turner', '1998-07-25', 'caleb.turner@example.com', '573-555-0198', '77 West Elm Road', 'Columbia', 'MO', '65201');

INSERT INTO income_records
    (applicant_id, employer_name, job_title, hours_per_week, gross_monthly_income)
VALUES
    (1, 'Gateway Grocery', 'Cashier', 32, 2150.00),
    (2, 'River City Services', 'Office Assistant', 40, 2980.00),
    (3, 'Mid-Missouri Care', 'Support Aide', 25, 1875.00);

INSERT INTO household_members
    (applicant_id, first_name, last_name, relationship_to_applicant, date_of_birth, gross_monthly_income)
VALUES
    (1, 'Taylor', 'Reed', 'Child', '2015-09-10', 0),
    (2, 'Luis', 'Lopez', 'Spouse', '1984-01-22', 2100.00),
    (3, 'Avery', 'Turner', 'Child', '2020-03-06', 0);

-- Demo employee login (username: employee1, password: Medicaid2026!). Change before real use.
INSERT INTO employees (username, password_hash)
VALUES ('employee1', '120000:5hnY1gZFJjk7pXArDcoj9A==:4wucAEdyInpnhLgWO3R8zBUdju67YUeCouMgU2aUCD4=');
