// Steven Tallyn 11/2/2026 Employee Data Access Object for the Medicaid Verification Tool

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

// Data Access Object: saves employees and checks employee logins using the
// SQLite database (the "employees" table).
// JB: I use this DAO as the only place where employee credentials interact with SQLite.
// JB: Keeping SQL out of the Swing form makes the login workflow easier to maintain and test.
public class EmployeeDao {

    // JB: PBKDF2 slows down offline password guessing; each account also receives its own random salt.
    private static final int ITERATIONS = 120_000;
    private static final int SALT_BYTES = 16;
    private static final int HASH_BITS = 256;

    private final String dbUrl;

    // Uses the database file in the folder the program is run from.
    // JB: The default constructor targets the sample database next to the running Java program.
    public EmployeeDao() {
        this("medicaid_employment_verification.db");
    }

    // Lets you point at the .db file anywhere on disk.
    // JB: An alternate database path lets me test against a temporary database without editing app code.
    public EmployeeDao(String dbFilePath) {
        this.dbUrl = "jdbc:sqlite:" + dbFilePath;
    }

    // Makes the employees table if the database does not have it yet,
    // so older copies of the .db file keep working.
    // JB: I create the employees table only when necessary so older team databases remain compatible.
    public void createTableIfMissing() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS employees (
                    employee_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL
                )
                """;
        try (Connection conn = DriverManager.getConnection(dbUrl);
             Statement st = conn.createStatement()) {
            st.execute(sql);
        }
    }

    // Saves the employee (hashing the password) and returns the new employee_id.
    // The id is also stored on the Employee object itself.
    // JB: I bind SQL parameters to avoid string-based SQL injection and hash the password before insertion.
    public int save(Employee e) throws SQLException {
        String sql = "INSERT INTO employees (username, password_hash) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, e.getUsername());
            ps.setString(2, hashPassword(e.getPassword()));
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    int id = keys.getInt(1);
                    e.setEmployeeId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Employee was saved, but no employee ID was returned.");
    }

    // Checks a login attempt. Returns the Employee if the username and password
    // match, or null if they do not. The returned Employee has no password set.
    // JB: A successful login returns an Employee without the password; bad credentials return null.
    public Employee login(String username, String password) throws SQLException {
        String sql = "SELECT employee_id, username, password_hash FROM employees WHERE username = ?";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && passwordMatches(password, rs.getString("password_hash"))) {
                    Employee e = new Employee();
                    e.setEmployeeId(rs.getInt("employee_id"));
                    e.setUsername(rs.getString("username"));
                    return e;
                }
            }
        }
        return null;
    }

    // ---------------- password hashing ----------------

    // JB: I generate a fresh salt for every new account and store iterations:salt:hash in Base64.
    private static String hashPassword(String password) {
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        byte[] hash = pbkdf2(password.toCharArray(), salt, ITERATIONS);
        return ITERATIONS + ":" + Base64.getEncoder().encodeToString(salt)
                + ":" + Base64.getEncoder().encodeToString(hash);
    }

    // JB: I derive a verifier from the entered password and compare it using a timing-resistant operation.
    private static boolean passwordMatches(String password, String stored) {
        try {
            String[] parts = stored.split(":");
            int iterations = Integer.parseInt(parts[0]);
            byte[] salt = Base64.getDecoder().decode(parts[1]);
            byte[] expected = Base64.getDecoder().decode(parts[2]);
            byte[] actual = pbkdf2(password.toCharArray(), salt, iterations);
            return MessageDigest.isEqual(expected, actual); // constant-time compare
        } catch (RuntimeException ex) {
            return false; // malformed stored value
        }
    }

    // JB: This helper centralizes PBKDF2-HMAC-SHA256 so account creation and login use matching settings.
    private static byte[] pbkdf2(char[] password, byte[] salt, int iterations) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, HASH_BITS);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException ex) {
            throw new IllegalStateException("Password hashing is not available.", ex);
        }
    }

    // Small helper to add an employee from the command line:
    //   java -cp ... EmployeeDao <username> <password>
    // JB: This optional command-line tool creates a staff account; I avoid printing the password.
    public static void main(String[] args) {
        // JB: I reject missing/blank credentials before asking SQLite to create an employee.
        if (args.length != 2 || args[0].isBlank() || args[1].length() < 10) {
            System.out.println("Usage: java EmployeeDao <username> <password-with-at-least-10-characters>");
            return;
        }
        try {
            EmployeeDao dao = new EmployeeDao();
            dao.createTableIfMissing();
            int id = dao.save(new Employee(args[0], args[1]));
            System.out.println("Employee created. ID: " + id);
        } catch (SQLException error) {
            System.out.println("Database error: " + error.getMessage());
        }
    }
}
