//Alp Magrali, 10/4/2026, Database Java-SQL class

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ApplicantDatabase {
    private static final String DB_URL = "jdbc:sqlite:medicaid_employment_verification.db";

    public static int addApplicant(
            String firstName,
            String lastName,
            String dateOfBirth,
            String email,
            String phone,
            String address,
            String city,
            String state,
            String zipCode) throws SQLException {

        String sql = """
                INSERT INTO applicants
                    (first_name, last_name, date_of_birth, email, phone,
                     address_line1, city, state, zip_code)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection connection = DriverManager.getConnection(DB_URL);
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, dateOfBirth);
            statement.setString(4, email);
            statement.setString(5, phone);
            statement.setString(6, address);
            statement.setString(7, city);
            statement.setString(8, state);
            statement.setString(9, zipCode);
            statement.executeUpdate();

            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }
        }

        throw new SQLException("Applicant was saved, but no applicant ID was returned.");
    }

    public static void showApplicants() throws SQLException {
        String sql = """
                SELECT applicant_id, first_name, last_name, application_status, submitted_at
                FROM applicants
                ORDER BY applicant_id
                """;

        try (Connection connection = DriverManager.getConnection(DB_URL);
             Statement statement = connection.createStatement();
             ResultSet results = statement.executeQuery(sql)) {

            while (results.next()) {
                System.out.printf(
                        "%d: %s %s | %s | %s%n",
                        results.getInt("applicant_id"),
                        results.getString("first_name"),
                        results.getString("last_name"),
                        results.getString("application_status"),
                        results.getString("submitted_at"));
            }
        }
    }

    public static void main(String[] args) {
        try {
            int id = addApplicant(
                    "Sam",
                    "Miller",
                    "1993-12-14",
                    "sam.miller@example.com",
                    "417-555-0108",
                    "410 Market Street",
                    "Springfield",
                    "MO",
                    "65806");

            System.out.println("Application received. Applicant ID: " + id);
            showApplicants();
        } catch (SQLException error) {
            System.out.println("Database error: " + error.getMessage());
        }
    }
}
