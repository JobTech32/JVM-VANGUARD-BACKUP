// Steven Tallyn 11/2/2026 Employee class
// JB: I keep employee profile data in this small model. Passwords are only supplied during account creation and are not printed in toString().
public class Employee {

    // Set by the database after the employee is saved
    private int employeeId;

    private String username;
    private String password;

    // JB: I need a no-argument constructor when a successful database query reconstructs an employee profile.
    public Employee() {
    }

    // JB: I use this constructor to pass employee credentials into the DAO when I create an account.
    public Employee(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // JB: These accessor methods expose the employee ID, username and temporary password to the appropriate program components.
    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    // The password is left out on purpose so it can't end up in logs.
    // JB: I intentionally leave the password out of diagnostic output to avoid leaking credentials into console logs.
    @Override
    public String toString() {
        return employeeId + ": " + username;
    }
}
