// Steven Tallyn 11/2/2026 Employee login window for the Medicaid Verification Tool

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;
import java.util.Arrays;

// JB: I keep the sign-in window separate from the applicant form so only staff credentials reach EmployeeDao.
public class EmployeeLogin extends JFrame {

    private static final Color NEXT_BLUE = new Color(0x0067C0);
    private static final Color ERROR_RED = new Color(0xB00020);

    private final EmployeeDao employeeDao;
    private final JTextField txtUsername = new JTextField(20);
    private final JPasswordField txtPassword = new JPasswordField(20);
    private final JLabel message = new JLabel(" ");

    // JB: I use the default DAO for normal launches from the application menu.
    public EmployeeLogin() {
        this(new EmployeeDao());
    }

    // JB: Allowing a DAO argument makes the window easier to test with a separate SQLite database.
    public EmployeeLogin(EmployeeDao employeeDao) {
        super("Employee Login");
        this.employeeDao = employeeDao;

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel title = new JLabel("Employee portal");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        JLabel subtitle = new JLabel("Sign in to view applicants");
        subtitle.setForeground(Color.GRAY);

        message.setForeground(ERROR_RED);

        // JB: The blue action button sends credentials through the same validation method each time.
        JButton btnLogin = new JButton("Log in");
        btnLogin.setUI(new javax.swing.plaf.basic.BasicButtonUI());
        btnLogin.setOpaque(true);
        btnLogin.setBorderPainted(false);
        btnLogin.setBackground(NEXT_BLUE);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(btnLogin.getFont().deriveFont(Font.BOLD, 14f));
        btnLogin.setBorder(new EmptyBorder(8, 20, 8, 20));
        btnLogin.addActionListener(e -> attemptLogin());

        // JB: GridBagLayout keeps the username, password, feedback, and submit button organized.
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 4);
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2; form.add(title, c);
        c.gridy = 1; c.insets = new Insets(0, 4, 12, 4); form.add(subtitle, c);
        c.insets = new Insets(4, 4, 4, 4); c.gridwidth = 1;
        c.gridy = 2; c.gridx = 0; form.add(new JLabel("Username:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; form.add(txtUsername, c);
        c.gridy = 3; c.gridx = 0; c.fill = GridBagConstraints.NONE; form.add(new JLabel("Password:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; form.add(txtPassword, c);
        c.gridy = 4; c.gridx = 0; c.gridwidth = 2; form.add(message, c);
        c.gridy = 5; c.fill = GridBagConstraints.NONE; c.anchor = GridBagConstraints.EAST; form.add(btnLogin, c);

        JPanel content = new JPanel(new BorderLayout());
        content.setBorder(new EmptyBorder(20, 24, 20, 24));
        content.add(form, BorderLayout.CENTER);
        setContentPane(content);

        // Enter key in either field logs in
        getRootPane().setDefaultButton(btnLogin);

        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    // JB: I validate that fields are present, check the stored PBKDF2 hash, and open the portal only for an authenticated employee.
    private void attemptLogin() {
        String username = txtUsername.getText().trim();
        char[] password = txtPassword.getPassword();

        if (username.isEmpty() || password.length == 0) {
            message.setText("Enter your username and password.");
            return;
        }

        try {
            employeeDao.createTableIfMissing();
            Employee employee = employeeDao.login(username, new String(password));
            if (employee == null) {
                message.setText("Incorrect username or password.");
                txtPassword.setText("");
                return;
            }
            dispose();
            new EmployeePortal(employee, new ApplicantDao()).setVisible(true);
        } catch (SQLException error) {
            message.setText("Database error: " + error.getMessage());
        } finally {
            Arrays.fill(password, '\0'); // don't leave the password sitting in memory
        }
    }

    // JB: A standalone entry point lets me test employee login without running the full applicant wizard.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new EmployeeLogin().setVisible(true);
        });
    }
}
