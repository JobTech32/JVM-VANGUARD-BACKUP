// MO HealthNet Application - 4-page wizard by John Bumbera & Steven Tallyn
// Java / Swing (JDK 11+, no external dependencies)
// Build & run:
//   javac MOHealthNetApplication.java
//   java MOHealthNetApplication
 
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.function.Predicate;
 
public class MOHealthNetApplication extends JFrame {
 
    private static final int TOTAL_STEPS = 4;
    private int currentStep = 1;
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter
            .ofPattern("MM/dd/uuuu").withResolverStyle(ResolverStyle.STRICT);
    private static final Color NEXT_BLUE = new Color(0x0067C0);
    private static final Color ERROR_RED = new Color(0xB00020);
    private static final Color INVALID_BACKGROUND = new Color(0xFFE1E1);
 
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cardPanel = new JPanel(cardLayout);
    private final JLabel formSubtitle = new JLabel();
    private final JButton backButton = new JButton("< Back");
    private final JButton nextButton = new JButton("Next >");
    private final JLabel validationMessage = new JLabel("Invalid input. Correct the red fields.");
    private final List<FieldRule> fieldRules = new ArrayList<>();
    private boolean membersValidationRequested;
    private boolean certificationValidationRequested;
 
    // Step 1 fields
    private JTextField txtFirstName, txtLastName, txtDob, txtSsn;
    private JComboBox<String> cboGender;
    private JTextField txtAddress, txtCity, txtZip, txtPhone, txtEmail;
    private JSpinner spnHoursWorked;
    private JRadioButton radPhone, radMail;
    private JSpinner spnHousehold;
    private JCheckBox chkPregnant;
    private JLabel uploadStatus;
 
    // Step 2 fields
    private JTextField txtEmployer, txtGrossIncome, txtOtherIncome, txtTotalIncome, txtHhReadOnly;
    private JComboBox<String> cboPayFreq, cboIncomeType;
 
    // Step 3 fields
    private DefaultTableModel membersModel;
    private JTable membersTable;
    private JRadioButton radCitizen, radNonCitizen;
 
    // Step 4 fields
    private JTextArea reviewSummary;
    private JCheckBox chkCertify;
    private JTextField txtSignature, txtDate;
 
    public MOHealthNetApplication() {
        super("MOHealthNetApplication");
        setIconImages(createApplicationIcons());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(760, 800);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(0xF3, 0xF3, 0xF3));
 
        setJMenuBar(buildMenuBar());
        add(buildToolbar(), BorderLayout.NORTH);
        add(buildFormBody(), BorderLayout.CENTER);
        add(buildNavButtons(), BorderLayout.SOUTH);
        installValidation();
 
        showStep(1);
        setVisible(true);
    }
 
    private JMenuBar buildMenuBar() {
        JMenuBar bar = new JMenuBar();
        for (String name : new String[]{"File", "Edit", "View", "Application", "Help"}) {
            JMenu menu = new JMenu(name);
            if ("Application".equals(name)) {
                // JB: I provide the staff entry inside the existing Java app without changing the applicant wizard.
                JMenuItem employeeLogin = new JMenuItem("Employee Login...");
                // JB: This opens the authenticated SQLite portal workflow instead of showing applicant data directly.
                employeeLogin.addActionListener(e -> new EmployeeLogin().setVisible(true));
                menu.add(employeeLogin);
            }
            bar.add(menu);
        }
        return bar;
    }
 
    private JToolBar buildToolbar() {
        JToolBar tb = new JToolBar();
        tb.setFloatable(false);
        for (String name : new String[]{"New", "Open", "Save"}) tb.add(new JButton(name));
        tb.addSeparator();
        for (String name : new String[]{"Cut", "Copy", "Paste"}) tb.add(new JButton(name));
        return tb;
    }
 
    private JPanel buildFormBody() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBorder(new EmptyBorder(15, 20, 15, 20));
        outer.setBackground(new Color(0xF3, 0xF3, 0xF3));
 
        JLabel title = new JLabel("MO HealthNet application");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        formSubtitle.setForeground(Color.GRAY);
 
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(new Color(0xF3, 0xF3, 0xF3));
        header.setBorder(new EmptyBorder(0, 0, 12, 0));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        formSubtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        header.add(title);
        header.add(formSubtitle);
        validationMessage.setForeground(ERROR_RED);
        validationMessage.setAlignmentX(Component.LEFT_ALIGNMENT);
        validationMessage.setVisible(false);
        header.add(validationMessage);
 
        outer.add(header, BorderLayout.NORTH);
 
        cardPanel.setBackground(new Color(0xF3, 0xF3, 0xF3));
        cardPanel.add(buildStep1(), "1");
        cardPanel.add(buildStep2(), "2");
        cardPanel.add(buildStep3(), "3");
        cardPanel.add(buildStep4(), "4");
 
        JScrollPane scroll = new JScrollPane(cardPanel);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        outer.add(scroll, BorderLayout.CENTER);
        return outer;
    }
 
    private JPanel buildNavButtons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        panel.setBackground(new Color(0xF0, 0xF0, 0xF0));
        stylePrimaryButton(nextButton);
        backButton.setPreferredSize(new Dimension(nextButton.getPreferredSize()));
        backButton.setFont(nextButton.getFont());
        backButton.addActionListener(e -> { if (currentStep > 1) showStep(currentStep - 1); });
        nextButton.addActionListener(e -> onNextClicked());
        panel.add(backButton);
        panel.add(nextButton);
 
        JLabel statusReady = new JLabel("Ready");
        JLabel statusAuto = new JLabel("Autosaved 2 min ago");
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBorder(new EmptyBorder(4, 12, 4, 12));
        statusBar.add(statusReady, BorderLayout.WEST);
        statusBar.add(statusAuto, BorderLayout.EAST);
 
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.add(panel, BorderLayout.CENTER);
        wrapper.add(statusBar, BorderLayout.SOUTH);
        return wrapper;
    }

    private static void stylePrimaryButton(JButton button) {
        // The Windows native button painter can ignore setBackground().
        button.setUI(new BasicButtonUI());
        button.setContentAreaFilled(true);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setBorder(new EmptyBorder(10, 20, 10, 20));
        button.setBackground(NEXT_BLUE);
        button.setForeground(Color.WHITE);
        button.setFont(button.getFont().deriveFont(Font.BOLD, 14f));
        button.setPreferredSize(new Dimension(190, 42));
    }

    private static List<Image> createApplicationIcons() {
        List<Image> icons = new ArrayList<>();
        for (int size : new int[]{16, 24, 32, 48, 64, 128}) {
            BufferedImage icon = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
            Graphics2D graphics = icon.createGraphics();
            try {
                graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                graphics.setColor(Color.WHITE);
                int corner = Math.max(2, size / 6);
                graphics.fillRoundRect(0, 0, size, size, corner, corner);
                int thickness = Math.max(4, size / 4);
                int length = size * 3 / 4;
                int armStart = (size - length) / 2;
                int centerStart = (size - thickness) / 2;
                graphics.setColor(new Color(0xD32F2F));
                graphics.fillRect(centerStart, armStart, thickness, length);
                graphics.fillRect(armStart, centerStart, length, thickness);
            } finally {
                graphics.dispose();
            }
            icons.add(icon);
        }
        return icons;
    }
 
    private TitledBorder titled(String title) {
        return BorderFactory.createTitledBorder(title);
    }
 
    private JPanel fieldRow(String label, JComponent field) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setBackground(new Color(0xF3, 0xF3, 0xF3));
        row.setBorder(new EmptyBorder(6, 0, 6, 0));
        JLabel lbl = new JLabel(label);
        lbl.setPreferredSize(new Dimension(160, 22));
        row.add(lbl, BorderLayout.WEST);
        row.add(field, BorderLayout.CENTER);
        return row;
    }
 
    // ---------------- DATE PICKER ----------------
    /** A read-only date field plus a calendar button; clicking either opens the calendar popup. */
    private JPanel datePickerField(JTextField field) {
        field.setEditable(false);
        field.setBackground(Color.WHITE);
        field.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        field.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { showDatePicker(field); }
        });
        JButton btn = new JButton("\uD83D\uDCC5");
        btn.setToolTipText("Select date from calendar");
        btn.addActionListener(e -> showDatePicker(field));
 
        JPanel p = new JPanel(new BorderLayout(4, 0));
        p.setOpaque(false);
        p.add(field, BorderLayout.CENTER);
        p.add(btn, BorderLayout.EAST);
        return p;
    }
 
    /** Modal month/year calendar. Writes the chosen date into target as MM/dd/yyyy. Future dates are disabled. */
    private void showDatePicker(JTextField target) {
        final LocalDate today = LocalDate.now();
        LocalDate parsed;
        try {
            parsed = LocalDate.parse(target.getText().trim(), DATE_FMT);
        } catch (Exception ex) {
            parsed = today;
        }
        if (parsed.isAfter(today)) parsed = today;
        final LocalDate selected = parsed;
        final YearMonth[] shown = { YearMonth.from(selected) };
        final boolean[] updating = { false };
 
        JDialog dlg = new JDialog(this, "Select date of birth", true);
 
        JButton prev = new JButton("<");
        JButton next = new JButton(">");
        String[] monthNames = new String[12];
        for (int i = 0; i < 12; i++) {
            monthNames[i] = java.time.Month.of(i + 1).getDisplayName(TextStyle.FULL, Locale.US);
        }
        JComboBox<String> cboMonth = new JComboBox<>(monthNames);
        JComboBox<Integer> cboYear = new JComboBox<>();
        for (int y = today.getYear(); y >= 1900; y--) cboYear.addItem(y);
 
        JPanel grid = new JPanel(new GridLayout(7, 7, 2, 2));
        grid.setPreferredSize(new Dimension(300, 210));
 
        Runnable refresh = () -> {
            updating[0] = true;
            cboMonth.setSelectedIndex(shown[0].getMonthValue() - 1);
            cboYear.setSelectedItem(shown[0].getYear());
            updating[0] = false;
            prev.setEnabled(shown[0].getYear() > 1900 || shown[0].getMonthValue() > 1);
            next.setEnabled(shown[0].isBefore(YearMonth.from(today)));
 
            grid.removeAll();
            for (String h : new String[]{"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"}) {
                JLabel l = new JLabel(h, SwingConstants.CENTER);
                l.setFont(l.getFont().deriveFont(Font.BOLD));
                grid.add(l);
            }
            int offset = shown[0].atDay(1).getDayOfWeek().getValue() % 7; // Sunday = 0
            for (int i = 0; i < offset; i++) grid.add(new JLabel());
            for (int d = 1; d <= shown[0].lengthOfMonth(); d++) {
                final LocalDate date = shown[0].atDay(d);
                JButton b = new JButton(String.valueOf(d));
                b.setMargin(new Insets(2, 2, 2, 2));
                b.setFocusPainted(false);
                if (date.isAfter(today)) b.setEnabled(false);
                if (date.equals(selected)) {
                    b.setOpaque(true);
                    b.setBackground(new Color(0, 120, 215));
                    b.setForeground(Color.WHITE);
                }
                b.addActionListener(e -> {
                    target.setText(date.format(DATE_FMT));
                    dlg.dispose();
                });
                grid.add(b);
            }
            grid.revalidate();
            grid.repaint();
        };
 
        prev.addActionListener(e -> { shown[0] = shown[0].minusMonths(1); refresh.run(); });
        next.addActionListener(e -> { shown[0] = shown[0].plusMonths(1); refresh.run(); });
        ActionListener jump = e -> {
            if (updating[0] || cboYear.getSelectedItem() == null) return;
            YearMonth ym = YearMonth.of((Integer) cboYear.getSelectedItem(), cboMonth.getSelectedIndex() + 1);
            shown[0] = ym.isAfter(YearMonth.from(today)) ? YearMonth.from(today) : ym;
            refresh.run();
        };
        cboMonth.addActionListener(jump);
        cboYear.addActionListener(jump);
 
        JPanel nav = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        nav.add(prev);
        nav.add(cboMonth);
        nav.add(cboYear);
        nav.add(next);
 
        JPanel content = new JPanel(new BorderLayout(0, 8));
        content.setBorder(new EmptyBorder(10, 10, 10, 10));
        content.add(nav, BorderLayout.NORTH);
        content.add(grid, BorderLayout.CENTER);
 
        refresh.run();
        dlg.setContentPane(content);
        dlg.pack();
        dlg.setResizable(false);
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }
 
    // ---------------- STEP 1 ----------------
    private JPanel buildStep1() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(0xF3, 0xF3, 0xF3));
 
        JPanel grpApplicant = new JPanel();
        grpApplicant.setLayout(new BoxLayout(grpApplicant, BoxLayout.Y_AXIS));
        grpApplicant.setBorder(titled("Applicant details"));
        grpApplicant.setBackground(new Color(0xF3, 0xF3, 0xF3));
        txtFirstName = new JTextField("Jordan");
        txtLastName = new JTextField("Taylor");
        txtDob = new JTextField("04/12/1990");
        txtSsn = new JTextField();
        cboGender = new JComboBox<>(new String[]{"Female", "Male", "Prefer not to answer"});
        grpApplicant.add(fieldRow("First name:", txtFirstName));
        grpApplicant.add(fieldRow("Last name:", txtLastName));
        grpApplicant.add(fieldRow("Date of birth:", datePickerField(txtDob)));
        grpApplicant.add(fieldRow("SSN (optional):", txtSsn));
        grpApplicant.add(fieldRow("Gender:", cboGender));
        spnHoursWorked = new JSpinner(new SpinnerNumberModel(40, 0, 168, 1));
        grpApplicant.add(fieldRow("Hours worked (per week):", spnHoursWorked));
 
        JPanel grpContact = new JPanel();
        grpContact.setLayout(new BoxLayout(grpContact, BoxLayout.Y_AXIS));
        grpContact.setBorder(titled("Contact and address"));
        grpContact.setBackground(new Color(0xF3, 0xF3, 0xF3));
        txtAddress = new JTextField("412 Rangeline St");
        txtCity = new JTextField("Columbia");
        txtZip = new JTextField("65201");
        txtPhone = new JTextField("(573) 555-0134");
        txtEmail = new JTextField("jordan.taylor@example.com");
        grpContact.add(fieldRow("Address:", txtAddress));
        grpContact.add(fieldRow("City:", txtCity));
        grpContact.add(fieldRow("ZIP:", txtZip));
        grpContact.add(fieldRow("Phone:", txtPhone));
        grpContact.add(fieldRow("Email (optional):", txtEmail));
 
        radPhone = new JRadioButton("Phone", true);
        radMail = new JRadioButton("Mail");
        ButtonGroup contactGroup = new ButtonGroup();
        contactGroup.add(radPhone);
        contactGroup.add(radMail);
        JPanel radioRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        radioRow.setBackground(new Color(0xF3, 0xF3, 0xF3));
        radioRow.add(new JLabel("Preferred contact method:"));
        radioRow.add(radPhone);
        radioRow.add(radMail);
        grpContact.add(radioRow);
 
        JPanel grpHousehold = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        grpHousehold.setBorder(titled("Household"));
        grpHousehold.setBackground(new Color(0xF3, 0xF3, 0xF3));
        spnHousehold = new JSpinner(new SpinnerNumberModel(3, 1, 20, 1));
        chkPregnant = new JCheckBox("Pregnant");
        grpHousehold.add(new JLabel("Household size:"));
        grpHousehold.add(spnHousehold);
        grpHousehold.add(Box.createHorizontalStrut(200));
        grpHousehold.add(chkPregnant);
 
        JPanel grpDocs = new JPanel();
        grpDocs.setLayout(new BoxLayout(grpDocs, BoxLayout.Y_AXIS));
        grpDocs.setBorder(titled("Supporting documents"));
        grpDocs.setBackground(new Color(0xF3, 0xF3, 0xF3));
        JPanel uploadRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        uploadRow.setBackground(new Color(0xF3, 0xF3, 0xF3));
        JButton btnUpload = new JButton("\uD83D\uDD12 Upload document...");
        uploadStatus = new JLabel("No file selected");
        uploadStatus.setForeground(Color.GRAY);
        uploadStatus.setFont(uploadStatus.getFont().deriveFont(Font.ITALIC));
        btnUpload.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            int result = chooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File f = chooser.getSelectedFile();
                uploadStatus.setText(f.getName());
                uploadStatus.setForeground(Color.BLACK);
                uploadStatus.setFont(uploadStatus.getFont().deriveFont(Font.PLAIN));
            }
        });
        uploadRow.add(btnUpload);
        uploadRow.add(uploadStatus);
        JLabel hint = new JLabel("Accepted: PDF, JPG, PNG (max 10 MB). Connection is encrypted (TLS 1.2).");
        hint.setForeground(Color.GRAY);
        hint.setFont(hint.getFont().deriveFont(11f));
        hint.setAlignmentX(Component.LEFT_ALIGNMENT);
        grpDocs.add(uploadRow);
        grpDocs.add(hint);
 
        panel.add(grpApplicant);
        panel.add(grpContact);
        panel.add(grpHousehold);
        panel.add(grpDocs);
        return panel;
    }
 
    // ---------------- STEP 2 ----------------
    private JPanel buildStep2() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(0xF3, 0xF3, 0xF3));
 
        JPanel grpEmployment = new JPanel();
        grpEmployment.setLayout(new BoxLayout(grpEmployment, BoxLayout.Y_AXIS));
        grpEmployment.setBorder(titled("Employment income — Jordan Taylor"));
        grpEmployment.setBackground(new Color(0xF3, 0xF3, 0xF3));
        txtEmployer = new JTextField("Boone County Schools");
        txtGrossIncome = new JTextField("$2,150.00");
        cboPayFreq = new JComboBox<>(new String[]{"Monthly", "Biweekly", "Weekly"});
        grpEmployment.add(fieldRow("Employer name:", txtEmployer));
        grpEmployment.add(fieldRow("Monthly gross income:", txtGrossIncome));
        grpEmployment.add(fieldRow("Pay frequency:", cboPayFreq));
 
        JPanel grpOther = new JPanel();
        grpOther.setLayout(new BoxLayout(grpOther, BoxLayout.Y_AXIS));
        grpOther.setBorder(titled("Other income"));
        grpOther.setBackground(new Color(0xF3, 0xF3, 0xF3));
        cboIncomeType = new JComboBox<>(new String[]{"Child support", "Social Security", "Unemployment", "Self-employment", "None"});
        txtOtherIncome = new JTextField("$300.00");
        grpOther.add(fieldRow("Income type:", cboIncomeType));
        grpOther.add(fieldRow("Monthly amount:", txtOtherIncome));
 
        JPanel grpSummary = new JPanel();
        grpSummary.setLayout(new BoxLayout(grpSummary, BoxLayout.Y_AXIS));
        grpSummary.setBorder(titled("Household income summary"));
        grpSummary.setBackground(new Color(0xF3, 0xF3, 0xF3));
        txtHhReadOnly = new JTextField("3");
        txtHhReadOnly.setEditable(false);
        txtHhReadOnly.setBackground(new Color(0xEC, 0xEC, 0xEC));
        txtTotalIncome = new JTextField("$2,450.00");
        txtTotalIncome.setEditable(false);
        txtTotalIncome.setBackground(new Color(0xEC, 0xEC, 0xEC));
        grpSummary.add(fieldRow("Household size:", txtHhReadOnly));
        grpSummary.add(fieldRow("Total monthly income:", txtTotalIncome));
 
        JLabel hint = infoHint("Enter income for every household member age 18 or older.");
 
        panel.add(grpEmployment);
        panel.add(grpOther);
        panel.add(grpSummary);
        panel.add(hint);
        return panel;
    }
 
    // ---------------- STEP 3 ----------------
    private JPanel buildStep3() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(0xF3, 0xF3, 0xF3));
 
        JPanel grpMembers = new JPanel(new BorderLayout(0, 8));
        grpMembers.setBorder(titled("Household members"));
        grpMembers.setBackground(new Color(0xF3, 0xF3, 0xF3));
        membersModel = new DefaultTableModel(new Object[]{"Name", "Date of birth", "Relationship", "SSN"}, 0);
        membersModel.addRow(new Object[]{"Jordan Taylor", "04/12/1990", "Self", "XXX-XX-XXXX"});
        membersModel.addRow(new Object[]{"Avery Taylor", "09/03/2015", "Child", "XXX-XX-XXXX"});
        membersModel.addRow(new Object[]{"Riley Taylor", "01/21/2018", "Child", "XXX-XX-XXXX"});
        membersTable = new JTable(membersModel);
        membersTable.setRowHeight(24);
        membersTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        membersTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean selected, boolean focused, int row, int column) {
                // Renderers are reused; reset colors before painting the next cell.
                setBackground(table.getBackground());
                setForeground(table.getForeground());
                super.getTableCellRendererComponent(table, value, selected, focused, row, column);
                int modelRow = table.convertRowIndexToModel(row);
                int modelColumn = table.convertColumnIndexToModel(column);
                boolean invalid = membersValidationRequested && !validMemberCell(modelRow, modelColumn);
                if (invalid) {
                    setBackground(INVALID_BACKGROUND);
                    setForeground(ERROR_RED);
                    setBorder(BorderFactory.createLineBorder(ERROR_RED, 2));
                }
                setToolTipText(invalid ? "Invalid input. " + memberHint(modelColumn) : null);
                return this;
            }
        });
        JScrollPane tableScroll = new JScrollPane(membersTable);
        tableScroll.setPreferredSize(new Dimension(650, 130));
        JButton btnAdd = new JButton("+ Add household member");
        btnAdd.addActionListener(e -> membersModel.addRow(new Object[]{"", "", "", ""}));
        JPanel addRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addRow.setBackground(new Color(0xF3, 0xF3, 0xF3));
        addRow.add(btnAdd);
        grpMembers.add(tableScroll, BorderLayout.CENTER);
        grpMembers.add(addRow, BorderLayout.SOUTH);
 
        JPanel grpCitizen = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 8));
        grpCitizen.setBorder(titled("Citizenship & immigration status"));
        grpCitizen.setBackground(new Color(0xF3, 0xF3, 0xF3));
        radCitizen = new JRadioButton("U.S. citizen", true);
        radNonCitizen = new JRadioButton("Qualified non-citizen");
        ButtonGroup citizenGroup = new ButtonGroup();
        citizenGroup.add(radCitizen);
        citizenGroup.add(radNonCitizen);
        grpCitizen.add(radCitizen);
        grpCitizen.add(radNonCitizen);
 
        JLabel hint = infoHint("Include everyone who lives in the home, even if they are not applying for coverage.");
 
        panel.add(grpMembers);
        panel.add(grpCitizen);
        panel.add(hint);
        return panel;
    }
 
    // ---------------- STEP 4 ----------------
    private JPanel buildStep4() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(0xF3, 0xF3, 0xF3));
 
        JPanel grpReview = new JPanel(new BorderLayout());
        grpReview.setBorder(titled("Review your information"));
        grpReview.setBackground(new Color(0xF3, 0xF3, 0xF3));
        reviewSummary = new JTextArea(9, 40);
        reviewSummary.setEditable(false);
        reviewSummary.setBackground(new Color(0xF3, 0xF3, 0xF3));
        reviewSummary.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        grpReview.add(reviewSummary, BorderLayout.CENTER);
 
        JPanel grpCert = new JPanel();
        grpCert.setLayout(new BoxLayout(grpCert, BoxLayout.Y_AXIS));
        grpCert.setBorder(titled("Certification & signature"));
        grpCert.setBackground(new Color(0xF3, 0xF3, 0xF3));
        chkCertify = new JCheckBox("<html>I certify that the information provided in this application is<br>" +
                "true and complete to the best of my knowledge.</html>", true);
        txtSignature = new JTextField("Jordan Taylor");
        txtDate = new JTextField(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
        grpCert.add(chkCertify);
        grpCert.add(fieldRow("Full legal name to sign:", txtSignature));
        grpCert.add(fieldRow("Date:", txtDate));
 
        JLabel hint = infoHint("After submitting, you will receive a confirmation number and can track your application status online.");
 
        panel.add(grpReview);
        panel.add(grpCert);
        panel.add(hint);
        return panel;
    }
 
    private JLabel infoHint(String text) {
        JLabel hint = new JLabel("<html>&#8505; " + text + "</html>");
        hint.setOpaque(true);
        hint.setBackground(new Color(0xE8, 0xF3, 0xFC));
        hint.setForeground(new Color(0x1a, 0x5a, 0x8a));
        hint.setBorder(new EmptyBorder(8, 10, 8, 10));
        hint.setAlignmentX(Component.LEFT_ALIGNMENT);
        return hint;
    }

    // ---------------- INPUT VALIDATION ----------------
    private static final class FieldRule {
        final int step;
        final String name;
        final JTextField field;
        final Predicate<String> validator;
        final String hint;
        final javax.swing.border.Border normalBorder;
        final Color normalBackground;
        final String normalTooltip;
        boolean checked;
        boolean valid = true;

        FieldRule(int step, String name, JTextField field,
                Predicate<String> validator, String hint) {
            this.step = step;
            this.name = name;
            this.field = field;
            this.validator = validator;
            this.hint = hint;
            normalBorder = field.getBorder();
            normalBackground = field.getBackground();
            normalTooltip = field.getToolTipText();
        }

        boolean validate() {
            checked = true;
            valid = validator.test(field.getText().trim());
            field.setBackground(valid ? normalBackground : INVALID_BACKGROUND);
            field.setBorder(valid ? normalBorder : BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(ERROR_RED, 2), new EmptyBorder(0, 2, 0, 2)));
            field.setToolTipText(valid ? normalTooltip : "Invalid input. " + hint);
            return valid;
        }
    }

    private void installValidation() {
        addRule(1, "First name", txtFirstName, MOHealthNetApplication::validName,
                "Enter a name using letters, spaces, apostrophes, periods, or hyphens.");
        addRule(1, "Last name", txtLastName, MOHealthNetApplication::validName,
                "Enter a name using letters, spaces, apostrophes, periods, or hyphens.");
        addRule(1, "Date of birth", txtDob, MOHealthNetApplication::validPastDate,
                "Select a real date on or before today (MM/DD/YYYY).");
        addRule(1, "SSN", txtSsn, MOHealthNetApplication::validOptionalSsn,
                "Use 9 digits or XXX-XX-XXXX with digits, or leave this optional field blank.");
        addRule(1, "Address", txtAddress, text -> !text.isEmpty(), "Enter your street address.");
        addRule(1, "City", txtCity, MOHealthNetApplication::validName, "Enter a city name.");
        addRule(1, "ZIP", txtZip, text -> text.matches("[0-9]{5}(-[0-9]{4})?"),
                "Use 5 digits or ZIP+4, for example 65201 or 65201-1234.");
        addRule(1, "Phone", txtPhone,
                text -> (radMail.isSelected() && text.isEmpty()) || validPhone(text),
                "Use a 10-digit phone number, optionally with country code 1. Required for phone contact.");
        addRule(1, "Email", txtEmail, MOHealthNetApplication::validOptionalEmail,
                "Use an address like name@example.com, or leave this optional field blank.");
        addSpinnerRule(1, "Hours worked", spnHoursWorked, 0, 168);
        addSpinnerRule(1, "Household size", spnHousehold, 1, 20);

        addRule(2, "Employer", txtEmployer, text -> !text.isEmpty() || zeroMoney(txtGrossIncome.getText()),
                "Enter an employer when gross income is greater than zero.");
        addRule(2, "Monthly gross income", txtGrossIncome, text -> parseMoney(text) != null,
                "Enter a nonnegative amount with at most 2 decimal places, for example 2150.00.");
        addRule(2, "Other income", txtOtherIncome, text -> parseMoney(text) != null
                        && (!"None".equals(cboIncomeType.getSelectedItem())
                            || parseMoney(text).signum() == 0),
                "Enter a nonnegative amount with at most 2 decimal places; use 0 when income type is None.");
        addRule(4, "Signature", txtSignature, MOHealthNetApplication::validName,
                "Enter your full legal name.");
        addRule(4, "Signature date", txtDate, MOHealthNetApplication::validPastDate,
                "Enter a real date on or before today (MM/DD/YYYY).");

        onTextChanged(txtGrossIncome, () -> {
            refreshCheckedRules();
            updateIncomeSummary();
        });
        onTextChanged(txtOtherIncome, this::updateIncomeSummary);
        spnHousehold.addChangeListener(e -> updateIncomeSummary());
        radPhone.addActionListener(e -> refreshCheckedRules());
        radMail.addActionListener(e -> refreshCheckedRules());
        cboIncomeType.addActionListener(e -> refreshCheckedRules());
        chkCertify.addActionListener(e -> {
            if (certificationValidationRequested) markCertification();
            updateValidationMessage();
        });
        membersModel.addTableModelListener(e -> {
            membersValidationRequested = true;
            membersTable.repaint();
            updateValidationMessage();
        });
        updateIncomeSummary();
    }

    private void addRule(int step, String name, JTextField field,
            Predicate<String> validator, String hint) {
        FieldRule rule = new FieldRule(step, name, field, validator, hint);
        fieldRules.add(rule);
        field.addFocusListener(new FocusAdapter() {
            @Override public void focusLost(FocusEvent event) {
                rule.validate();
                updateValidationMessage();
            }
        });
        onTextChanged(field, () -> {
            if (rule.checked) rule.validate();
            updateValidationMessage();
        });
    }

    private void addSpinnerRule(int step, String name, JSpinner spinner, int min, int max) {
        JFormattedTextField field = ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField();
        // Preserve invalid typing so it can be highlighted instead of silently reverted.
        field.setFocusLostBehavior(JFormattedTextField.PERSIST);
        addRule(step, name, field, text -> validWholeNumber(text, min, max),
                "Enter a whole number from " + min + " to " + max + ".");
    }

    private static void onTextChanged(JTextField field, Runnable action) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent event) { action.run(); }
            @Override public void removeUpdate(DocumentEvent event) { action.run(); }
            @Override public void changedUpdate(DocumentEvent event) { action.run(); }
        });
    }

    private void refreshCheckedRules() {
        for (FieldRule rule : fieldRules) if (rule.checked) rule.validate();
        updateValidationMessage();
    }

    private static boolean validName(String text) {
        return text.matches("\\p{L}[\\p{L}\\p{M} .\\-'\u2019]*");
    }

    private static boolean validPastDate(String text) {
        try {
            return !LocalDate.parse(text.trim(), DATE_FMT).isAfter(LocalDate.now());
        } catch (DateTimeParseException ex) {
            return false;
        }
    }

    private static boolean validOptionalSsn(String text) {
        return text.isEmpty() || text.matches("(?:[0-9]{9}|[0-9]{3}-[0-9]{2}-[0-9]{4})");
    }

    private static boolean validPhone(String text) {
        return text.matches("(?:\\+?1[ .-]?)?(?:\\([0-9]{3}\\)|[0-9]{3})[ .-]?[0-9]{3}[ .-]?[0-9]{4}");
    }

    private static boolean validOptionalEmail(String text) {
        if (text.isEmpty()) return true;
        int at = text.indexOf('@');
        if (at < 1 || at > 64 || at != text.lastIndexOf('@') || text.length() > 254) return false;
        String local = text.substring(0, at);
        String domain = text.substring(at + 1);
        if (!local.matches("[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+")
                || local.startsWith(".") || local.endsWith(".") || local.contains("..")) return false;
        String[] labels = domain.split("\\.", -1);
        if (labels.length < 2) return false;
        for (String label : labels) {
            if (label.length() > 63 || !label.matches("[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?")) return false;
        }
        return labels[labels.length - 1].matches("[A-Za-z]{2,}|xn--[A-Za-z0-9-]+");
    }

    private static boolean validWholeNumber(String text, int min, int max) {
        if (!text.matches("[0-9]+")) return false;
        try {
            int value = Integer.parseInt(text);
            return value >= min && value <= max;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private static BigDecimal parseMoney(String text) {
        String value = text.trim();
        if (!value.matches("\\$?(?:(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\\.[0-9]{1,2})?|\\.[0-9]{1,2})")) {
            return null;
        }
        return new BigDecimal(value.replace("$", "").replace(",", ""));
    }

    private static boolean zeroMoney(String text) {
        BigDecimal value = parseMoney(text);
        return value != null && value.signum() == 0;
    }

    private void updateIncomeSummary() {
        txtHhReadOnly.setText(spnHousehold.getValue().toString());
        BigDecimal gross = parseMoney(txtGrossIncome.getText());
        BigDecimal other = parseMoney(txtOtherIncome.getText());
        txtTotalIncome.setText(gross == null || other == null ? "Invalid input"
                : NumberFormat.getCurrencyInstance(Locale.US).format(gross.add(other)));
    }

    private boolean validMemberCell(int row, int column) {
        Object value = membersModel.getValueAt(row, column);
        String text = value == null ? "" : value.toString().trim();
        switch (column) {
            case 0: return validName(text);
            case 1: return validPastDate(text);
            case 2: return text.matches("\\p{L}[\\p{L}\\p{M} /.'\u2019-]*");
            case 3: return validOptionalSsn(text) || text.equalsIgnoreCase("XXX-XX-XXXX");
            default: return true;
        }
    }

    private static String memberHint(int column) {
        String[] hints = {"Enter a name.", "Use a real date on or before today (MM/DD/YYYY).",
                "Enter a relationship.", "Use a 9-digit SSN, keep the demo mask, or leave it blank."};
        return hints[column];
    }

    private boolean hasMemberErrors() {
        for (int row = 0; row < membersModel.getRowCount(); row++) {
            for (int column = 0; column < membersModel.getColumnCount(); column++) {
                if (!validMemberCell(row, column)) return true;
            }
        }
        return false;
    }

    private void markCertification() {
        boolean valid = chkCertify.isSelected();
        chkCertify.setOpaque(!valid);
        chkCertify.setBackground(valid ? UIManager.getColor("CheckBox.background") : INVALID_BACKGROUND);
        chkCertify.setForeground(valid ? UIManager.getColor("CheckBox.foreground") : ERROR_RED);
    }

    private void updateValidationMessage() {
        boolean invalid = false;
        for (FieldRule rule : fieldRules) {
            if (rule.step == currentStep && rule.checked && !rule.valid) invalid = true;
        }
        if (currentStep == 3 && membersValidationRequested && hasMemberErrors()) invalid = true;
        if (currentStep == 4 && certificationValidationRequested && !chkCertify.isSelected()) invalid = true;
        validationMessage.setVisible(invalid);
    }

    private boolean validateStep(int step, boolean showDialog) {
        List<String> errors = new ArrayList<>();
        JComponent firstInvalid = null;
        if (step == 3 && membersTable.isEditing() && !membersTable.getCellEditor().stopCellEditing()) {
            errors.add("Household members: finish editing the current cell.");
            firstInvalid = membersTable;
        }
        for (FieldRule rule : fieldRules) {
            if (rule.step == step && !rule.validate()) {
                errors.add(rule.name + ": " + rule.hint);
                if (firstInvalid == null) firstInvalid = rule.field;
            }
        }
        if (step == 3) {
            membersValidationRequested = true;
            for (int row = 0; row < membersModel.getRowCount(); row++) {
                for (int column = 0; column < membersModel.getColumnCount(); column++) {
                    if (!validMemberCell(row, column)) {
                        errors.add("Household member " + (row + 1) + ", "
                                + membersModel.getColumnName(column) + ": " + memberHint(column));
                        if (firstInvalid == null) {
                            firstInvalid = membersTable;
                            membersTable.changeSelection(row, column, false, false);
                            membersTable.scrollRectToVisible(membersTable.getCellRect(row, column, true));
                        }
                    }
                }
            }
            membersTable.repaint();
        }
        if (step == 4) {
            certificationValidationRequested = true;
            markCertification();
            if (!chkCertify.isSelected()) {
                errors.add("Certification: check the box before submitting.");
                if (firstInvalid == null) firstInvalid = chkCertify;
            }
        }
        updateValidationMessage();
        if (!errors.isEmpty()) {
            if (showDialog) showInvalidInput("Invalid input. Correct the red fields:\n\n"
                    + String.join("\n", errors));
            if (firstInvalid != null) {
                firstInvalid.scrollRectToVisible(new Rectangle(0, 0, firstInvalid.getWidth(), firstInvalid.getHeight()));
                firstInvalid.requestFocusInWindow();
            }
            return false;
        }
        if (step == 1) {
            spnHoursWorked.setValue(Integer.parseInt(((JSpinner.DefaultEditor)
                    spnHoursWorked.getEditor()).getTextField().getText().trim()));
            spnHousehold.setValue(Integer.parseInt(((JSpinner.DefaultEditor)
                    spnHousehold.getEditor()).getTextField().getText().trim()));
        }
        updateIncomeSummary();
        return true;
    }

    protected void showInvalidInput(String message) {
        JOptionPane.showMessageDialog(this, message, "Invalid input", JOptionPane.ERROR_MESSAGE);
    }
 
    private void showStep(int step) {
        currentStep = step;
        cardLayout.show(cardPanel, String.valueOf(step));
 
        String[] titles = {"Applicant details", "Household income", "Household members", "Review & submit"};
        formSubtitle.setText("Step " + step + " of " + TOTAL_STEPS + " — " + titles[step - 1]);
 
        backButton.setEnabled(step > 1);
        if (step == TOTAL_STEPS) {
            nextButton.setText("Submit Application");
            nextButton.setBackground(new Color(30, 142, 62));
            updateReviewSummary();
        } else {
            nextButton.setText("Next >");
            nextButton.setBackground(NEXT_BLUE);
        }
        updateValidationMessage();
    }
 
    private void updateReviewSummary() {
        reviewSummary.setText(
                "Applicant:              " + txtFirstName.getText() + " " + txtLastName.getText() + "\n" +
                "Date of birth:          " + txtDob.getText() + "\n" +
                "Address:                " + txtAddress.getText() + ", " + txtCity.getText() + ", MO " + txtZip.getText() + "\n" +
                "Phone:                  " + txtPhone.getText() + "\n" +
                "Email:                  " + txtEmail.getText() + "\n" +
                "Hours worked/week:      " + spnHoursWorked.getValue() + "\n" +
                "Household size:         " + spnHousehold.getValue() + "\n" +
                "Total monthly income:   " + txtTotalIncome.getText() + "\n" +
                "Documents uploaded:     " + uploadStatus.getText()
        );
    }
 
    private void onNextClicked() {
        if (!validateStep(currentStep, true)) return;
        if (currentStep < TOTAL_STEPS) {
            showStep(currentStep + 1);
        } else {
            String confirmation = "MHN-" + new SimpleDateFormat("yyyyMMddHHmm").format(new Date());
            JOptionPane.showMessageDialog(this,
                    "Application submitted!\nConfirmation number: " + confirmation,
                    "Submitted", JOptionPane.INFORMATION_MESSAGE);
        }
    }
 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new MOHealthNetApplication();
        });
    }
}
