// JB: I built this employee review window on the team's existing SQLite login and applicant DAO.
// JB: The portal shows saved class-project data only after EmployeeLogin authenticates the user.

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;

public class EmployeePortal extends JFrame {

    // JB: I keep these columns consistent with the Applicant model and include the review status and submission date.
    private static final String[] COLUMNS = {
            "ID", "Name", "Date of birth", "Age", "Email", "Phone",
            "Address", "City", "State", "ZIP", "Status", "Submitted"
    };
    private static final String[] STATUSES = {"Received", "Under Review", "Needs Correction", "Verified"};

    private final ApplicantDao applicantDao;
    private final DefaultTableModel model = new DefaultTableModel(COLUMNS, 0) {
        // JB: I stop users from modifying database fields by typing directly into the table.
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    private final JTextField searchBox = new JTextField(22);
    private final JComboBox<String> statusChoice = new JComboBox<>(STATUSES);
    private final JLabel countLabel = new JLabel(" ");

    // JB: This constructor is called only after the password has been verified by EmployeeLogin.
    public EmployeePortal(Employee employee, ApplicantDao applicantDao) {
        super("MEVA - Employee Portal");
        this.applicantDao = applicantDao;
        // JB: Closing the portal should not unexpectedly close the separate applicant window.
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1130, 580);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("Saved applicants");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        JLabel signedIn = new JLabel("Signed in as " + employee.getUsername());
        signedIn.setForeground(Color.GRAY);
        JLabel notice = new JLabel("Class project database only — not an official Medicaid system");
        notice.setForeground(new Color(0x4E6682));

        JPanel titleBlock = new JPanel();
        titleBlock.setLayout(new BoxLayout(titleBlock, BoxLayout.Y_AXIS));
        titleBlock.add(title);
        titleBlock.add(signedIn);
        titleBlock.add(notice);

        // JB: The employee can reload saved rows or end the session without changing the applicant wizard.
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> loadApplicants());
        JButton btnLogout = new JButton("Log out");
        btnLogout.addActionListener(e -> {
            // JB: I close the current portal and require a new login before data is visible again.
            dispose();
            SwingUtilities.invokeLater(() -> new EmployeeLogin().setVisible(true));
        });
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.add(btnRefresh);
        buttons.add(btnLogout);

        JPanel header = new JPanel(new BorderLayout());
        header.setBorder(new EmptyBorder(12, 16, 8, 16));
        header.add(titleBlock, BorderLayout.WEST);
        header.add(buttons, BorderLayout.EAST);

        // JB: The read-only table can be sorted by clicking its column headings.
        table.setRowHeight(24);
        table.setRowSorter(sorter);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int[] widths = {40, 150, 95, 40, 190, 110, 150, 100, 45, 80, 115, 140};
        for (int i = 0; i < widths.length; i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(new EmptyBorder(0, 16, 0, 16));

        // JB: I filter the existing rows by ID or name as the employee types, without issuing new database queries.
        searchBox.setToolTipText("Search by applicant ID or name");
        searchBox.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { filterRows(); }
            @Override public void removeUpdate(DocumentEvent e) { filterRows(); }
            @Override public void changedUpdate(DocumentEvent e) { filterRows(); }
        });

        // JB: After an employee selects a row, changing a status uses a prepared SQLite UPDATE statement.
        JButton btnApplyStatus = new JButton("Save selected status");
        btnApplyStatus.addActionListener(e -> saveSelectedStatus());
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 8));
        actions.add(new JLabel("Search:"));
        actions.add(searchBox);
        actions.add(new JLabel("Change selected row to:"));
        actions.add(statusChoice);
        actions.add(btnApplyStatus);

        JPanel center = new JPanel(new BorderLayout());
        center.add(actions, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);
        countLabel.setBorder(new EmptyBorder(8, 16, 10, 16));
        add(header, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(countLabel, BorderLayout.SOUTH);

        loadApplicants();
    }

    // JB: I escape the text before making a case-insensitive regular expression, so punctuation can't break search.
    private void filterRows() {
        String query = searchBox.getText().trim();
        sorter.setRowFilter(query.isEmpty() ? null : RowFilter.regexFilter("(?i)" + Pattern.quote(query), 0, 1));
        countLabel.setText(table.getRowCount() + " matching applicants (class demo)");
    }

    // JB: I convert the sorted table's selected index to the model index before retrieving the true applicant ID.
    // JB: This avoids updating the wrong record when the employee sorts or filters the visible table.
    private void saveSelectedStatus() {
        int selected = table.getSelectedRow();
        if (selected < 0) {
            JOptionPane.showMessageDialog(this, "Select one applicant row first.", "Select a record", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int modelRow = table.convertRowIndexToModel(selected);
        int applicantId = ((Number) model.getValueAt(modelRow, 0)).intValue();
        String status = (String) statusChoice.getSelectedItem();
        try {
            if (applicantDao.updateStatus(applicantId, status)) {
                // JB: I refresh from SQLite instead of assuming the update succeeded visually.
                loadApplicants();
                countLabel.setText("Saved status for applicant #" + applicantId + ": " + status);
            } else {
                countLabel.setText("The selected applicant could not be found in the database.");
            }
        } catch (SQLException | IllegalArgumentException error) {
            countLabel.setText("Could not save review status: " + error.getMessage());
        }
    }

    // JB: I reload applicant records from SQLite whenever the portal opens, Refresh is pressed, or a status changes.
    private void loadApplicants() {
        model.setRowCount(0);
        try {
            List<Applicant> applicants = applicantDao.findAll();
            for (Applicant a : applicants) {
                model.addRow(new Object[]{
                        a.getApplicantId(),
                        a.getFirstName() + " " + a.getLastName(),
                        a.getDateOfBirth(), a.getAge(), a.getEmail(), a.getPhone(),
                        a.getAddressLine1(), a.getCity(), a.getState(), a.getZipCode(),
                        a.getApplicationStatus(), a.getSubmittedAt()
                });
            }
            filterRows();
        } catch (SQLException error) {
            countLabel.setText("Could not load applicants: " + error.getMessage());
        }
    }
}
