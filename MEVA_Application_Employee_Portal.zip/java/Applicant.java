//Steven Tallyn 10/5/2026, Applicant Class for the Medicaid Verification Tool

import java.time.LocalDate;
import java.time.Period;

// This is the applicant class that holds all of a single applicant's data
// Which is transferred to the database via ApplicantDao
public class Applicant {

    // Set by the database after the applicant is saved
    private int applicantId;

    // Values that come from the form
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private String email;
    private String phone;
    private String addressLine1;
    private String city;
    private String state = "MO";   // defaults to MO because it is the Missouri Medicaid System
    private String zipCode;

    // System values: filled in by the database, not by the form
    private String applicationStatus; // starts as "Received"
    private String submittedAt;

    // Default constructor for the Applicant Class
    public Applicant() {
    }

    // List of getters and setters for the applicant class
    public int getApplicantId() { return applicantId; }
    public void setApplicantId(int applicantId) { this.applicantId = applicantId; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    // Age is calculated from date of birth, so there is no setAge() and no age column.
    public int getAge() {
        if (dateOfBirth == null) {
            return 0;
        }
        return Period.between(dateOfBirth, LocalDate.now()).getYears();
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddressLine1() { return addressLine1; }
    public void setAddressLine1(String addressLine1) { this.addressLine1 = addressLine1; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getZipCode() { return zipCode; }
    public void setZipCode(String zipCode) { this.zipCode = zipCode; }

    public String getApplicationStatus() { return applicationStatus; }
    public void setApplicationStatus(String applicationStatus) { this.applicationStatus = applicationStatus; }

    public String getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(String submittedAt) { this.submittedAt = submittedAt; }

    @Override
    public String toString() {
        return applicantId + ": " + firstName + " " + lastName
                + " (age " + getAge() + ") | " + city + ", " + state
                + " | " + applicationStatus;
    }
}
