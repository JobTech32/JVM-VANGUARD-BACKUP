// Steven Tallyn, 10/5/2026 Applicant Data Access Object for the Medicaid Verification Tool

// SQL imports
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//Other imports
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

// Data Access Object: saves and loads Applicant objects using the
// SQLite database (the "applicants" table).

public class ApplicantDao {

    private final String dbUrl;

    // Uses the database file in the folder the program is run from.
    public ApplicantDao() {
        this("medicaid_employment_verification.db");
    }

    // Lets you point at the .db file anywhere on disk.
    public ApplicantDao(String dbFilePath) {
        this.dbUrl = "jdbc:sqlite:" + dbFilePath;
    }

     // Saves the applicant and returns the new applicant_id.
     // The id is also stored on the Applicant object itself.
    public int save(Applicant a) throws SQLException {
        String sql = """
                INSERT INTO applicants
                    (first_name, last_name, date_of_birth, email, phone,
                     address_line1, city, state, zip_code)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = DriverManager.getConnection(dbUrl);
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, a.getFirstName());
            ps.setString(2, a.getLastName());
            ps.setString(3, a.getDateOfBirth().toString()); // stored as text: yyyy-MM-dd
            ps.setString(4, a.getEmail());
            ps.setString(5, a.getPhone());
            ps.setString(6, a.getAddressLine1());
            ps.setString(7, a.getCity());
            ps.setString(8, a.getState());
            ps.setString(9, a.getZipCode());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    int id = keys.getInt(1);
                    a.setApplicantId(id);
                    return id;
                }
            }
        }
        throw new SQLException("Applicant was saved, but no applicant ID was returned.");
    }

    // Loads every applicant, including the status and submission time set by the database.
    // JB: I load applicant rows for the employee portal without exposing SQL to the Swing table.
    public List<Applicant> findAll() throws SQLException {
        String sql = """
                SELECT applicant_id, first_name, last_name, date_of_birth, email, phone,
                       address_line1, city, state, zip_code, application_status, submitted_at
                FROM applicants
                ORDER BY applicant_id
                """;

        List<Applicant> list = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(dbUrl);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Applicant a = new Applicant();
                a.setApplicantId(rs.getInt("applicant_id"));
                a.setFirstName(rs.getString("first_name"));
                a.setLastName(rs.getString("last_name"));
                a.setDateOfBirth(LocalDate.parse(rs.getString("date_of_birth")));
                a.setEmail(rs.getString("email"));
                a.setPhone(rs.getString("phone"));
                a.setAddressLine1(rs.getString("address_line1"));
                a.setCity(rs.getString("city"));
                a.setState(rs.getString("state"));
                a.setZipCode(rs.getString("zip_code"));
                a.setApplicationStatus(rs.getString("application_status"));
                a.setSubmittedAt(rs.getString("submitted_at"));
                list.add(a);
            }
        }
        return list;
    }

    // JB: I only permit the four intended review statuses, and I bind both the status and ID as SQL parameters.
    // JB: A saved change affects the local class-project SQLite database, not any official benefits system.
    public boolean updateStatus(int applicantId, String status) throws SQLException {
        if (applicantId <= 0 || !("Received".equals(status) || "Under Review".equals(status)
                || "Needs Correction".equals(status) || "Verified".equals(status))) {
            throw new IllegalArgumentException("Invalid application ID or review status.");
        }
        String sql = "UPDATE applicants SET application_status = ? WHERE applicant_id = ?";
        try (Connection conn = DriverManager.getConnection(dbUrl);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, applicantId);
            return ps.executeUpdate() == 1;
        }
    }
}
